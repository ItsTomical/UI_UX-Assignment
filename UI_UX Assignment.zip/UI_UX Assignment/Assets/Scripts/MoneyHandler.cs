using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class MoneyHandler : MonoBehaviour
{

    public TextMeshProUGUI doubloonsText;
    public int doubloonsCounter;
    // Start is called before the first frame update
    void Start()
    {
        doubloonsCounter = 100;
        ConvertToText();
    }

    public void ConvertToText()
    {
        doubloonsText.text = "Doubloons :  " + doubloonsCounter.ToString();
    }
}
