using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InventoryManager : MonoBehaviour
{
    
    public GameObject backpackItemPrefab;
    public SlotHandler[] backpackSlots;
    public void AddToBackpack(ShopItem shopItem)
    {
        for (int i = 0; i < backpackSlots.Length; i++)
        {
            SlotHandler slotCount = backpackSlots[i];
            DragHandler itemInSlot = slotCount.GetComponentInChildren<DragHandler>();
            if (itemInSlot == null)
            {
                SpawnInItem(shopItem, slotCount);
                return;
            }
        }
    }

    private void SpawnInItem(ShopItem shopItem, SlotHandler slotCount)
    {
        GameObject newGameObj = Instantiate(backpackItemPrefab, slotCount.transform);
        DragHandler backpackItem = newGameObj.GetComponent<DragHandler>();
        backpackItem.InitialiseBoughtItem(shopItem);
        
        
    }
}
