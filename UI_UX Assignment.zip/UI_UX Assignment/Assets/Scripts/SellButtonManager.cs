using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SellButtonManager : MonoBehaviour
{
    [Header("List of items sold")] 
    public InventoryManager inventoryManager;
    public ShopItem[] shopItem;

    public MoneyHandler wallet;
    //public MoneyHandler wallet;


    public void OnButtonClick(int i)
    {
        if (wallet.doubloonsCounter + shopItem[i].itemCost >= 0)
        {
            inventoryManager.AddToBackpack(shopItem[i]);
            wallet.doubloonsCounter += shopItem[i].itemCost;
            wallet.ConvertToText();
            Destroy(shopItem[i]);
        }
        else if (wallet.doubloonsCounter - shopItem[i].itemCost < 0)
        {
            Debug.Log("Broke");
        }
            
    }
}