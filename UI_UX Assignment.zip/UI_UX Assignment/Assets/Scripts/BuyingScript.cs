using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BuyingScript : MonoBehaviour
{
    [Header("List of items sold")] 
    public InventoryManager inventoryManager;
    public ShopItem[] shopItem;

    public MoneyHandler wallet;
    //public MoneyHandler wallet;


    public void OnButtonClick(int i)
    {
        if (wallet.doubloonsCounter - shopItem[i].itemCost >= 0)
        {
            inventoryManager.AddToBackpack(shopItem[i]);
            wallet.doubloonsCounter -= shopItem[i].itemCost;
            wallet.ConvertToText();
        }
        else if (wallet.doubloonsCounter - shopItem[i].itemCost < 0)
        {
            Debug.Log("Broke");
        }
            
    }
}
        
    

