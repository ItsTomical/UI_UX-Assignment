// using TMPro;
// using Unity.VisualScripting;
// using UnityEngine;
// using UnityEngine.UI;
//
// public class ShopManager : MonoBehaviour
// {
//     [Header("List of items sold")] 
//     public InventoryManager inventoryManager;
//     public ShopItem[] shopItem;
//     //public MoneyHandler wallet;
//
//     [Header("References")] 
//     [SerializeField] private Transform shopContainer;
//     [SerializeField] private GameObject shopItemPrefab;
//
//     //public 
//     private void Start()
//     {
//         PopulateShop();
//     }
//
//     private void PopulateShop()
//     {
//         for (int i = 0; i < shopItem.Length; i++)
//         {
//             ShopItem si = shopItem[i];
//             GameObject itemObject = Instantiate(shopItemPrefab, shopContainer);
//         
//             // This is the prefab's component order
//             // ShopUI (Image, Button)
//             //  - Border (Image)
//             //  - Sprite (Image)
//             //  - Cost (TextMeshProUGUI)
//         
//             // Add listener to the button
//             itemObject.GetComponent<Button>().onClick.AddListener(() => OnButtonClick(i));
//             
//             // Change the item's sprite
//             itemObject.transform.GetChild(0).GetComponent<Image>().sprite = si.sprite;
//
//             // Change the item's cost
//             itemObject.transform.GetChild(2).GetComponent<TextMeshProUGUI>().text = si.itemCost.ToString();
//         }   
//     }
//
//     private void OnButtonClick(int i)
//     {
//         inventoryManager.AddToBackpack(shopItem[i]);
//         
//         //wallet.moneyChange -= shopItem[id].itemCost;
//         //wallet.MakeText();
//     }
//     
// }