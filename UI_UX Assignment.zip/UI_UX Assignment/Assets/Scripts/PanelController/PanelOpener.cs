using UnityEngine;

public class PanelOpener : MonoBehaviour
{
    public GameObject Panel;

    public void OpenPanel()
    {
        if (Panel != null)
        {
            Animator animator = Panel.GetComponent<Animator>();
            if(animator != null)
            {
                animator.SetBool("open", true); // Set "open" parameter to true to open the panel
            }
        }
    }

    public void ClosePanel()
    {
        if (Panel != null)
        {
            Animator animator = Panel.GetComponent<Animator>();
            if(animator != null)
            {
                animator.SetBool("open", false); // Set "open" parameter to false to close the panel
            }
        }
    }
}